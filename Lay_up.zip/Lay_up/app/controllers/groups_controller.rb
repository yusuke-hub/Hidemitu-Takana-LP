class GroupsController < ApplicationController
  def index
  end

  def edit
  end

  def show
  end
end
