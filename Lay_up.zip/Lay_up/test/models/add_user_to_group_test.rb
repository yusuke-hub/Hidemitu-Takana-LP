require 'test_helper'

class AddUserToGroupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
